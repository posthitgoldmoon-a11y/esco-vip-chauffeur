package com.vipchauffeur.chauffeur

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
